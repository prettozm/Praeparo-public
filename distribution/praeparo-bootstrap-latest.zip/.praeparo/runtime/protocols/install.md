---
id: praeparo-protocol-install
type: protocol
owner: praeparo-runtime
---

# Protocole d'installation et de mise à niveau

Ce protocole s'applique quel que soit le transport : package téléchargé
depuis le point de distribution officiel ou archive ZIP fournie
directement par l'utilisateur. **Même package, même protocole.**

Ordre imposé : inspecter → détecter → comparer → décider → expliquer →
agir → vérifier. Jamais d'extraction aveugle.

## 1. Inspecter le dépôt cible

Chercher `.praeparo/runtime/package.yml` (source de vérité de la version
installée) et `.praeparo/installation.yml` (journal). Trois états :

- **absent** : pas de runtime (un `.praeparo/` ne contenant que des
  données projet compte comme absent — préserver ces données) ;
- **installé** : `package.yml` lisible avec `version` et
  `packageSchemaVersion` ;
- **cassé** : `package.yml` présent mais illisible ou incomplet.

## 2. Récupérer et vérifier le package

1. Lire le manifest officiel (`distribution/manifest.json` sur le site
   Praeparo) : version publiée, nom exact du package, SHA-256, taille,
   `packageSchemaVersion`, `minUpgradeFrom`. Le manifest est la source
   de vérité — jamais un nom de fichier « latest ».
2. Télécharger le package annoncé et vérifier son empreinte SHA-256
   contre le manifest. Empreinte divergente = arrêt immédiat.
3. Pour un ZIP fourni directement (sans manifest) : lire
   `.praeparo/runtime/package.yml` DANS l'archive pour connaître sa
   version, et vérifier chaque fichier contre les empreintes qu'il liste.
4. Inspecter les chemins de l'archive : ils doivent TOUS être sous
   `.praeparo/`, sans chemin absolu ni `..`, et ne contenir AUCUN
   chemin de données projet (`installation.yml`,
   `project-context.yml`…). Sinon : refuser le package.

## 3. Décider

Comparer version installée et version publiée :

| Constat | Décision |
| --- | --- |
| Runtime absent | **Installation** |
| Versions égales | **Aucune action** (idempotent) |
| Publiée plus récente, même `packageSchemaVersion`, installée ≥ `minUpgradeFrom` | **Mise à niveau directe** |
| Publiée plus récente, `packageSchemaVersion` différent | **Migration** (validation humaine) |
| Installée < `minUpgradeFrom` | **Non supporté** (options ci-dessous) |
| Installée plus récente que la publiée | **Ne rien faire**, le signaler |
| Installation cassée | **Non supporté** (réparation assistée) |

## 4. Annoncer avant d'agir

Toujours présenter la décision et son impact AVANT toute écriture, sur ce
modèle :

```text
Praeparo installé : 0.4.1 — version disponible : 0.6.0
Mise à niveau disponible.
Impact prévu :
- runtime Praeparo remplacé
- configuration projet conservée
- décisions et observations conservées
- aucun fichier hors de .praeparo/ modifié
Migration de schéma : aucune
```

**Politique de validation (documentée, jamais implicite)** : une mise à
niveau « runtime pur » (mêmes conditions que la ligne 3 du tableau) peut
être appliquée après cette annonce sans question bloquante, car le
package ne contient aucun chemin de données projet — l'écrasement est
impossible par construction. Installation initiale : idem. **Migration,
installation cassée, version non supportée ou toute écriture hors des
chemins possédés par Praeparo : validation humaine explicite obligatoire.**

## 5. Agir

- Vérifier d'abord que l'état Git du dépôt permet un retour arrière
  (`.praeparo/` sans modifications non commitées). Hors Git : copier
  l'existant en lieu sûr avant d'écrire.
- **Installation** : écrire les fichiers de l'archive, puis créer
  `.praeparo/installation.yml` conforme à
  [../schemas/installation.schema.json](../schemas/installation.schema.json).
- **Mise à niveau** : remplacer `.praeparo/START_HERE.md` et le contenu
  de `.praeparo/runtime/` par ceux de l'archive ; supprimer les fichiers
  de `runtime/` absents du nouveau `package.yml` (le runtime est
  possédé en bloc) ; ne toucher à RIEN d'autre ; ajouter une entrée au
  journal `installation.yml` (jamais le réécrire).
- **Migration** : prévisualiser les transformations, identifier les
  données impactées, sauvegarder, faire valider, appliquer, revalider,
  tracer dans le journal.

## 6. Vérifier le résultat

Relire depuis le disque (jamais depuis la mémoire) : chaque fichier listé
par `package.yml` existe et son SHA-256 correspond ; aucun fichier de
données projet n'a changé ; le journal porte la nouvelle entrée. En cas
d'échec : restaurer l'état antérieur et le dire.

## 7. Continuer

Runtime présent et vérifié → lire `.praeparo/START_HERE.md` et suivre
[setup.md](setup.md). L'installation ne modifie jamais automatiquement le
reste du dépôt.

## Version non supportée — options à présenter

```text
Version installée : X — version disponible : Y
Je ne peux pas garantir une migration directe sûre.
Raison : (la citer précisément)
Options :
1. rester sur la version actuelle ;
2. appliquer le chemin de migration supporté ;
3. sauvegarder et effectuer une migration assistée.
```
