---
id: praeparo-protocol-setup
type: protocol
owner: praeparo-runtime
---

# Protocole de configuration conversationnelle

Objectif : établir (ou faire évoluer) le setup Praeparo du projet —
`.praeparo/project-context.yml` d'abord, `project-blueprint.yml` si le
projet justifie d'aller plus loin. Le protocole est **réentrant** : il
sert au premier setup comme aux reconfigurations, sans jamais repartir
d'un questionnaire vierge quand un setup existe.

## 1. Observer avant de questionner

Inspecter ce qui est pertinent (sans lire des milliers de fichiers) :
structure du dépôt, gestionnaire de paquets, langages et frameworks,
dépendances principales, README et documentation, tests, scripts, build,
CI/CD, hooks, lint et formatage, Docker et déploiement, monorepo
éventuel, conventions visibles, fichiers d'instructions agent
(`CLAUDE.md`, `AGENTS.md`, règles locales), zones sensibles, et le
setup Praeparo existant.

## 2. Qualifier chaque information

Chaque constat porte un statut épistémique explicite :

- **détecté** : constaté dans un fichier précis (citer la source) ;
- **déclaré** : affirmé par l'utilisateur ou une documentation ;
- **inféré** : conclu par raisonnement — faillible, le dire ;
- **inconnu** : personne ne sait encore ;
- **contradictoire** : deux sources divergent (ex. README annonce Node 20,
  la CI utilise Node 22) — ne JAMAIS trancher à la place de l'utilisateur.

## 3. Présenter le setup avant la première question

Toujours ouvrir par un état des lieux : ce qui est détecté, ce qui est
repris du setup précédent, les dérives entre le setup accepté et le
réel, et les contradictions. L'utilisateur corrige ce résumé avant
d'aller plus loin.

## 4. Poser uniquement les questions nécessaires

Chaque dimension du setup est d'abord classée : sans objet / connue /
inférée (à confirmer) / inconnue / contradictoire. Seules les trois
dernières justifient une question. Un dépôt mûr en appelle peu ; un dépôt
vide en appelle davantage.

**Chaque question rappelle ce qui a été observé.** Modèle :

```text
Intégration continue
Détecté : GitHub Actions (tests, lint, build)
Non détecté : vérification documentaire, contrôle d'encodage
Souhaitez-vous conserver ce fonctionnement ou le faire évoluer ?
```

Les questions portent sur l'usage réel, jamais sur le choix d'une
méthodologie nommée : ce que vous construisez, qui travaille (humains,
agents, jusqu'où seuls), ce qui exige une validation humaine, quand une
tâche est terminée, quelles vérifications sont obligatoires, quels
documents doivent rester à jour, quelles zones sont sensibles, comment
vous livrez, quelles erreurs sont inacceptables. Ne posez aucune de ces
questions si le dépôt y répond déjà clairement.

## 5. Proposer, valider, matérialiser

1. Proposer le setup résultant en langage clair, chaque élément avec sa
   raison et son origine (détecté / déclaré / choisi).
2. Faire valider. Toute écriture HORS de `.praeparo/` (fichiers
   d'instructions agent, CI, documentation…) est présentée fichier par
   fichier et n'est appliquée qu'après accord explicite.
3. Matérialiser dans `.praeparo/project-context.yml` (et
   `project-blueprint.yml` le cas échéant).
4. Vérifier : relire les fichiers écrits, confirmer qu'ils disent ce qui
   a été validé, présenter le résultat.

## 6. Reconfiguration

Setup existant → le relire, réinspecter le dépôt, présenter le setup
actuel ET les dérives constatées, ne questionner que sur le nouveau ou le
contradictoire, proposer les changements en montrant ce qui est conservé.

## 7. Incertitudes

Une inconnue assumée s'écrit « Inconnu — décision utilisateur requise ».
Ne remplissez jamais un champ pour faire joli : un setup honnêtement
incomplet vaut mieux qu'un setup inventé.
