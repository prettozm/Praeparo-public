---
id: praeparo-start-here
type: start_here
owner: praeparo-runtime
---

# Praeparo dans ce dépôt — point d'entrée agent

Praeparo aide ce projet à rester compréhensible, vérifiable et durable :
qui fait quoi (humains, agents IA, automatisations), comment le travail
est vérifié, et ce qui reste sous contrôle humain. Ce dossier
`.praeparo/` en est l'installation locale. Praeparo n'est pas un
orchestrateur : rien ici ne s'exécute tout seul, et le projet fonctionne
sans Praeparo.

## Qui possède quoi

- **Praeparo possède** : ce fichier et `runtime/` (remplacés lors d'une
  mise à niveau — n'y stockez rien).
- **Le projet possède tout le reste**, notamment `installation.yml`
  (journal d'installation), `project-context.yml` (contexte machine),
  `project-blueprint.yml`, `decisions/`, `observations/`. Une mise à
  niveau du runtime ne les touche jamais.

## Ordre de lecture pour un agent frais

1. `runtime/package.yml` — version installée, inventaire vérifiable.
2. `installation.yml` — journal : quand, depuis où, décisions passées.
3. `project-context.yml` et `project-blueprint.yml` **s'ils existent** :
   le setup accepté. S'ils n'existent pas, le setup n'a pas encore eu lieu.
4. [runtime/protocols/setup.md](runtime/protocols/setup.md) — le protocole
   de configuration conversationnelle (premier setup ET reconfiguration).
5. [runtime/protocols/install.md](runtime/protocols/install.md) — seulement
   pour installer, vérifier ou mettre à niveau le runtime lui-même.

## Règles de conduite

- **Observer avant de questionner** : inspectez le dépôt et le setup
  existant, présentez ce que vous avez détecté, puis posez uniquement les
  questions réellement nécessaires (le protocole de setup les définit).
- **Statut épistémique explicite** : distinguez détecté / déclaré /
  inféré / inconnu / contradictoire. Ne tranchez jamais une contradiction
  à la place de l'utilisateur.
- **Jamais d'écrasement silencieux** : toute proposition de modification
  hors de `.praeparo/` est présentée et validée avant d'être appliquée.
- **En cas de doute** : dites ce que vous savez, ce que vous inférez et ce
  qui manque — une inconnue assumée vaut mieux qu'une invention.
