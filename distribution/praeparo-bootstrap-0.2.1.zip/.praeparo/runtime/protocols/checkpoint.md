---
id: praeparo-protocol-checkpoint
type: protocol
owner: praeparo-runtime
---

# Session Checkpoint / Handoff

Problème : longue session → contexte coûteux → session fraîche → perte de
continuité. Le checkpoint permet de reprendre avec un agent frais, un
autre modèle, un autre fournisseur, ou un humain.

## Ce qu'un checkpoint N'est PAS

Un résumé libre de la conversation. C'est un objet STRUCTURÉ
([../schemas/checkpoint.schema.json](../schemas/checkpoint.schema.json)),
versionnable, diffable, avec références vers les artefacts réels.

## Écrire un checkpoint

Un fichier par checkpoint dans `.praeparo/checkpoints/` (données
projet — créer le dossier seulement au premier checkpoint). Contenu
minimal : objectif courant, work item, décisions acceptées (et refusées
si utile), questions ouvertes, fichiers modifiés, fichiers volontairement
non touchés, preuves collectées (assertion → référence), état des
vérifications (honnête : « non exécuté » est une valeur valide),
limitations connues, risques, branche + HEAD + état non commité, actions
suivantes autorisées, validations humaines requises, contexte minimal
pour reprendre (références, pas de copies). Un checkpoint remplacé passe
`superseded` — jamais supprimé en silence.

## Reprendre depuis un checkpoint

```text
Lire le checkpoint actif.
Vérifier qu'il correspond encore au HEAD actuel.
Réinspecter les éléments nécessaires.
Continuer.
```

Le checkpoint n'est JAMAIS une vérité absolue : comparer sa branche et
son HEAD au dépôt courant. S'ils diffèrent, le checkpoint est périmé —
annoncer l'écart et réinspecter les zones potentiellement affectées
avant de continuer :

```text
checkpoint HEAD : abc123 — HEAD actuel : def456
Des commits ont eu lieu depuis le checkpoint.
Je réinspecte les zones touchées avant de reprendre.
```
