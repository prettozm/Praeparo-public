---
id: praeparo-protocol-setup
type: protocol
owner: praeparo-runtime
---

# Protocole de configuration conversationnelle

Objectif : établir (ou faire évoluer) le setup Praeparo du projet.
Le setup ne s'arrête pas à `.praeparo/project-context.yml` (qui décrit
le projet) : il aboutit à un **playbook** — `project-blueprint.yml` —
qui décrit comment le projet FONCTIONNE (cycle de travail, identité des
work items, rôles, autorité des agents, Definition of Done, preuves,
documents, Git, livraison, risques, contexte, politique de modèles).

Le protocole est **réentrant** : premier setup comme reconfiguration,
sans jamais repartir d'un questionnaire vierge quand un setup existe.
Quand il n'y a rien à faire, la réponse correcte est exactement :

```text
Configuration suffisante.
Aucune dérive significative détectée.
Aucune action recommandée.
```

Praeparo ne profite JAMAIS d'une invocation pour proposer davantage de
gouvernance.

## 1. Le questionnaire n'est pas improvisé

Le catalogue canonique
[../setup/questions.yml](../setup/questions.yml) définit les dimensions
que Praeparo considère importantes, leurs IDs stables, leurs questions
canoniques, leurs options et leurs conditions d'applicabilité. **Le
modèle n'invente pas de dimensions** : il décide seulement lesquelles
sont nécessaires ICI, selon les règles du §4. Les explications
d'accompagnement peuvent être reformulées librement ; les IDs, l'ordre
(celui du catalogue), les questions canoniques et les options, jamais.
Sur deux dépôts identiques, deux agents différents posent donc les mêmes
questions fondamentales.

## 2. Observer avant de questionner

Inspecter ce qui est pertinent (sans lire des milliers de fichiers) :
structure, gestionnaire de paquets, langages, dépendances, README et
documentation, tests, scripts, CI/CD, conventions visibles, fichiers
d'instructions agent (`CLAUDE.md`, `AGENTS.md`, règles locales),
zones sensibles, et le setup Praeparo existant (réponses déjà
enregistrées comprises).

## 3. Qualifier chaque dimension

Chaque dimension du catalogue reçoit un statut épistémique explicite
(ceux de Praeparo/NEXUS — pas de taxonomie parallèle) :

- **observé** : constaté dans un fichier précis (citer la source) ;
- **déclaré** : affirmé par l'utilisateur, une documentation faisant
  autorité, ou une réponse de setup enregistrée ;
- **inféré** : conclu par raisonnement — faillible, le dire ;
- **inconnu** : personne ne sait encore ;
- **contredit** : le déclaré diverge de l'observé (dérive) — l'observation
  prime factuellement mais la résolution reste à l'utilisateur ;
- **ambigu** : deux sources de même rang divergent — ne JAMAIS trancher
  à la place de l'utilisateur.

« Sans objet » n'est pas un statut : c'est l'applicabilité, calculée
depuis les conditions du catalogue (ex. les dimensions agents ne
s'appliquent que si des agents travaillent sur le projet).

## 4. Sélectionner les questions — règles déterministes

```text
sans objet                      → aucune question
observé / déclaré (non contredit) → aucune question
inféré non fondamental          → conservé comme inféré
inféré mais fondamental         → confirmation
inconnu et fondamental          → question
inconnu et standard             → défaut motivé du playbook (listé, modifiable)
contredit / ambigu              → résolution demandée
applicabilité indécidable       → question différée (après la réponse dont elle dépend)
```

Un dépôt mûr appelle peu de questions ; un dépôt vide appelle les
fondamentales. **Chaque question rappelle ce qui a été observé** :

```text
Intégration continue
Détecté : GitHub Actions (tests, lint, build)
Non détecté : vérification documentaire
Souhaitez-vous conserver ce fonctionnement ou le faire évoluer ?
```

Les questions portent sur l'usage réel, jamais sur le choix d'une
méthodologie nommée — et le playbook produit n'estampille jamais
l'utilisateur (« vous êtes Scrum ») : il dit ce que vous faites, qui le
fait, quand, avec quelles preuves, avec quelle autorité.

## 5. Présenter l'état des lieux avant la première question

Toujours ouvrir par : ce qui est observé, ce qui est repris du setup
précédent, les dérives (setup accepté vs réel) et les contradictions.
L'utilisateur corrige ce résumé avant d'aller plus loin.

## 6. Persister les réponses

Chaque réponse explicite est enregistrée dans
`.praeparo/project-context.yml` sous `setup:` (version du catalogue +
réponses par ID de dimension, schéma
[../schemas/setup-record.schema.json](../schemas/setup-record.schema.json)).
Une question tranchée n'est JAMAIS reposée — sauf dérive ou contradiction
nouvelle, qui rouvre uniquement la dimension concernée.

## 7. Du questionnaire au playbook (repo vide inclus)

Sur un dépôt existant : observer d'abord, le playbook reprend l'existant.
Sur un dépôt vide : Praeparo est prescripteur — il propose un système de
travail sain, jamais un simple fichier de contexte. Le parcours :

```text
questions fondamentales → compréhension → playbook proposé →
socle proposé → preview → validation humaine → matérialisation → vérification
```

À réponses identiques, le playbook proposé est structurellement
identique : la dérivation est mécanique (mêmes réponses ⇒ même système
de travail), seule la formulation des explications varie.

Le socle proposé, par pertinence — jamais une arborescence unique :

- **Toujours** (niveau A) : contexte projet, playbook, identité stable
  des work items (préfixes courts triables, adaptés au type de projet —
  jamais un système d'IDs séparé pour le kanban), Definition of Done,
  politique de preuves (assertion → preuve), politique d'agents
  (autonomie, interdits, validations humaines, effets par domaine),
  stratégie documentaire.
- **Par défaut mais léger** (niveau B) : une navigation documentaire
  exploitable par humains ET agents — un index dérivé des sources
  (jamais une seconde copie, jamais de prose inventée pour meubler) ;
  Graphify disponible mais dormant tant qu'il n'y a pas de matière.
- **Disponible, matérialisé sous condition** (niveau C) : Code
  Intelligence (sans objet sur un dépôt sans code ; sur un dépôt avec
  code, proposer — jamais installer en cachette : dire ce qui serait
  installé, pourquoi, coût, effets, dépendances), instructions locales,
  ADR, routage avancé, CI hooks.

## 8. Proposer, valider, matérialiser

1. Proposer le setup et le playbook en langage clair, chaque élément
   avec sa raison et son origine (observé / déclaré / défaut motivé).
2. Faire valider. Toute écriture HORS de `.praeparo/` est présentée
   fichier par fichier et n'est appliquée qu'après accord explicite.
3. Matérialiser : `project-context.yml` (réponses incluses) et
   `project-blueprint.yml`.
4. Vérifier : relire les fichiers écrits depuis le disque, confirmer
   qu'ils disent ce qui a été validé, présenter le résultat.

## 9. Reconfiguration et incertitudes

Setup existant → le relire, réinspecter, présenter setup + dérives, ne
questionner que le nouveau, le contredit ou l'ambigu. Une inconnue
assumée s'écrit « Inconnu — décision utilisateur requise ». Ne jamais
remplir un champ pour faire joli : un setup honnêtement incomplet vaut
mieux qu'un setup inventé.
